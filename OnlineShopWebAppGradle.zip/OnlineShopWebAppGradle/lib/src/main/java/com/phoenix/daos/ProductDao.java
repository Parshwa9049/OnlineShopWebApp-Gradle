package com.phoenix.daos;
/*
 * version 2.0
 * */
import java.util.List;

import com.phoenix.data.Product;

public interface ProductDao {

	Product getProductbyId(int id) ;
	List<Product> getAllProducts() ;
	void insert(Product product) ;
	void update(Product product) ;
	void delete(Product product) ;
}
