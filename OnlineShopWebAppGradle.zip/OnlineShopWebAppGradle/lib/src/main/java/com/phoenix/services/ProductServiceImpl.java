package com.phoenix.services;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.phoenix.daos.ProductDao;
import com.phoenix.daos.ProductDaoImpl;
import com.phoenix.data.Product;
import com.phoenix.exceptions.ProductNotFoundException;
import com.phoenix.exceptions.ServiceException;
/*
 * version 2.0
 * */
public class ProductServiceImpl implements ProductService{

	private ProductDao productDao;
	
	public ProductServiceImpl() {
		// TODO Auto-generated constructor stub
		productDao=new ProductDaoImpl();
	}
	@Override
	public List<Product> findAll() throws ServiceException {
		return productDao.getAllProducts();
	}

	@Override
	public Product findProductById(int id) throws ProductNotFoundException {
		Product product = productDao.getProductbyId(id);
	    if(product!=null)
	    	return product;
	    else
	    	throw new ProductNotFoundException("Product Not Found");
	}

	@Override
	public void add(Product product) throws ServiceException {
		productDao.insert(product);
	}

	@Override
	public void edit(Product product) throws ServiceException {
		productDao.update(product);
	}

	@Override
	public void remove(Product product) throws ServiceException {
		productDao.delete(product);
	}

	@Override
	public List<Product> findByName(String name) throws ServiceException {
		// TODO Auto-generated method stub
		
		  List<Product> dbProducts=findAll(); 
		  List<Product> productByName= new ArrayList<Product>(); 
		  for( Product product:dbProducts)
			  if(product.getName().equals(name)) 
			  { productByName.add(product);
			  }
		  return productByName;
					  
		  
		 
		
		
	}

	@Override
	public List<Product> findByBrand(String brand) throws ServiceException {
		// TODO Auto-generated method stub
		  List<Product> dbProducts=findAll(); 
		  List<Product> productByBrand= new ArrayList<Product>(); 
		  for( Product product:dbProducts)
			  if(product.getBrand().equals(brand)) 
			  { productByBrand.add(product);
			  }
		  return productByBrand;
	}

	@Override
	public List<Product> findByPrice(float price) throws ServiceException {
		// TODO Auto-generated method stub
		List<Product> prodList=new ArrayList<Product>();
		prodList.stream()
		.map(p->p.getPrice()==price)
		.collect(Collectors.toList());
		return prodList;
	}

	@Override
	public List<Product> findByPriceRange(float minPrice, float maxPrice) throws ServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findByNameAndBrand(String name, String brand) throws ServiceException {
		// TODO Auto-generated method stub
		
		List<Product> prodList=new ArrayList<Product>();
		prodList.stream()
		.map(p->p.getName()==name && p.getBrand()==brand)
		.collect(Collectors.toList());
		return prodList;
		
	}

	@Override
	public List<Product> findByNameAndprice(String name, float price) throws ServiceException {
		// TODO Auto-generated method stub
		
		List<Product> prodList=new ArrayList<Product>();
		prodList.stream()
		.map(p->p.getName()==name && p.getPrice()==price)
		.collect(Collectors.toList());
		return prodList;
		

		
	}

	@Override
	public List<Product> findByBrandAndPrice(String brand, float price) throws ServiceException {
		// TODO Auto-generated method stub
		List<Product> prodList=new ArrayList<Product>();
		prodList.stream()
		.map(p->p.getBrand()==brand && p.getPrice()==price)
		.collect(Collectors.toList());
		return prodList;
		
	}

	@Override
	public List<Product> sortByName() throws ServiceException {
		// TODO Auto-generated method stub
		List<Product> prodList= new ArrayList<Product>();
		prodList.stream().sorted(Comparator.comparing(Product::getName));
		prodList.forEach(System.out::println);
		return prodList;
	
		
		
		
	}

	@Override
	public List<Product> sortByBrand() throws ServiceException {
		// TODO Auto-generated method stub
		List<Product> prodList= new ArrayList<Product>();
		prodList.stream().sorted(Comparator.comparing(Product::getBrand));
		prodList.forEach(System.out::println);
		return prodList;
	}

	@Override
	public List<Product> sortByPrice() throws ServiceException {
		// TODO Auto-generated method stub
		List<Product> prodList= new ArrayList<Product>();
		prodList.stream().sorted(Comparator.comparing(Product::getPrice));
		prodList.forEach(System.out::println);
		return prodList;
		
	}

	@Override
	public List<Product> sortByPriceDesc() throws ServiceException {
		// TODO Auto-generated method stub
		List<Product> prodList= new ArrayList<Product>();
		prodList.stream().sorted(Comparator.comparing(Product::getPrice ).reversed());
		prodList.forEach(System.out::println);
		return prodList;
		
	}
	
	

}
