package com.phoenix.services;
/*
 * version 2.0
 * */
import java.util.List;

import com.phoenix.daos.LoginDao;
import com.phoenix.daos.LoginDaoImpl;
import com.phoenix.data.User;
import com.phoenix.exceptions.ServiceException;
import com.phoenix.exceptions.UserAlreadyExistException;
import com.phoenix.exceptions.UserNotFoundException;

public class LoginServiceImpl  implements LoginService{

	private LoginDao loginDao;
	
	public LoginServiceImpl() {
		loginDao = new LoginDaoImpl();
		}
	@Override
	public List<User> findAll() throws ServiceException {
		// TODO Auto-generated method stub
		
		return loginDao.getAllUsers();
	}

	@Override
	public User findUserById(String username1) throws UserNotFoundException {
		// TODO Auto-generated method stub
		
		
		User user = loginDao.getUserbyId(username1);
	    if(user!=null)
	    	return user;
	    else
	    	throw  new UserNotFoundException("User Not Found");
	}

	@Override
	public void add(User user) throws UserAlreadyExistException {
		loginDao.insert(user);
	}

	@Override
	public void edit(User user) throws ServiceException {
		loginDao.update(user);
		
	}

	@Override
	public void remove(User user) throws ServiceException {
		loginDao.delete(user);
		
	}

	@Override
	public String changePassword(String newPassword) throws ServiceException {
		// TODO Auto-generated method stub
		
			User user = new User();
			user.setPassword(newPassword);
			loginDao.update(user);
			return "Password Updated Successfully";
			
	

	
	}
	

}
